﻿using SalesRecordParserApi.Models;

namespace SalesRecordParserApi.Services
{
    public interface ISaleStatisticsService
    {
        SaleStatistics GetSaleStatistics();
    }
}
